/usr/bin/docker  exec -it db-db-1 /bin/bash
